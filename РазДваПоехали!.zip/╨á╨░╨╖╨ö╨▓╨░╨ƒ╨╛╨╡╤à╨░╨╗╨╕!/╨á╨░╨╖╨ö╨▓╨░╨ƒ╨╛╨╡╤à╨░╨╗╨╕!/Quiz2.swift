//
//  Quiz2.swift
//  РазДваПоехали!
//
//  Created by Влад on 25.03.16.
//  Copyright © 2016 Onanimus. All rights reserved.
//

import UIKit

class Quiz2: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}
